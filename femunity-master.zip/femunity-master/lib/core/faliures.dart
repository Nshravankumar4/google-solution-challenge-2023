class Failure {
  final String message;

  Failure(this.message);
}