package com.example.femunity

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
